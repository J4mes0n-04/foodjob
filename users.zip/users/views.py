from django.db import IntegrityError
from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth.models import User
from django.http import HttpResponseRedirect
from django.conf import settings
from django.core.mail import send_mail
from .models import Profile, Interest
from .forms import ProfileForm, InterestForm, MessageForm,CustomUserCreationForm
from .utils import paginateObjects, searchProfiles
from django.db.models import Q
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.utils.encoding import force_bytes, force_str
from django.contrib.auth.tokens import default_token_generator
from django.urls import reverse

# mail testing
import smtplib
import ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

def test_mail_sending(
    smtp_server="smtp.mail.ru",
    smtp_port=587,
    login="sberfair@mail.ru",
    password="ТВОЙ_ПАРОЛЬ_ИЛИ_ПАРОЛЬ_ПРИЛОЖЕНИЯ",
    recipient="example@domain.com",
    log_file="smtp_debug.log"
):
    import sys
    server = None  # ← чтобы избежать ошибки UnboundLocalError
    old_stdout = sys.stdout
    try:
        with open(log_file, "w", encoding="utf-8") as f:
            sys.stdout = f  # перенаправим stdout в лог-файл
            print("Connecting to SMTP server...")
            print(smtp_server,smtp_port )
            server = smtplib.SMTP(smtp_server, smtp_port, timeout=10)
            server.set_debuglevel(1)  # ← сюда пойдут все SMTP-команды
            print("Starting TLS...")
            server.starttls(context=ssl.create_default_context())

            print(f"Logging in as {login}...")
            server.login(login, password)

            message = MIMEMultipart("alternative")
            message["Subject"] = "Тестовая отправка от Django"
            message["From"] = login
            message["To"] = recipient

            html_content = """
            <html><body>
                <h1>Это тестовое письмо</h1>
                <p>Если вы это видите — SMTP работает 🎉</p>
            </body></html>
            """
            mime_html = MIMEText(html_content, "html")
            message.attach(mime_html)

            print(f"Sending email to {recipient}...")
            server.sendmail(login, recipient, message.as_string())
            print("Email sent successfully!")

    except Exception as e:
        # Пишем ошибку в лог-файл
        with open(log_file, "a", encoding="utf-8") as f:
            f.write(f"\nERROR OCCURRED:\n{str(e)}\n")

    finally:
        if server:
            server.quit()
        sys.stdout = old_stdout
        print(f"[LOG] SMTP log saved to {log_file}")

def test_mail(request):
    from foodjob.settings import EMAIL_HOST, EMAIL_HOST_PASSWORD, EMAIL_HOST_PORT, EMAIL_HOST_PROVIDER, EMAIL_HOST_USER,EMAIL_USE_TLS
    
    test_mail_sending(smtp_server=EMAIL_HOST,
                smtp_port=EMAIL_HOST_PORT,
                login=EMAIL_HOST_USER,
                password=EMAIL_HOST_PASSWORD,
                recipient="merly9863@yandex.ru",
                log_file="smtp_debug.log"
                )

def landing(request):
    if request.user.is_authenticated:
        return redirect('profiles')
    profiles, search_query = searchProfiles(request)
    custom_range, profiles = paginateObjects(request, 
        profiles, 3)
    context = {'profiles': profiles, 
    'search_query': search_query,
    'custom_range': custom_range}

    return render(request, 'landing.html', context)

def team(request):
    context={}
    return render(request, 'team.html', context)

def landingLogin(request):

    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        try:
            user = User.objects.get(username=username)
        except:
            messages.error(request, 
                'Такого пользователя нет в системе')
        user = authenticate(request, username=username, 
            password=password)

        if user is not None:
            login(request, user)
            return redirect(request.GET['next'] if 'next' 
                in request.GET else 'profiles')
        else:
            messages.error(request, 
                'Неверное имя пользователя или пароль')
    return redirect('landing')

def profiles(request):
    profiles, search_query = searchProfiles(request)
    custom_range, profiles = paginateObjects(request, 
        profiles, 3)
    context = {'profiles': profiles, 
    'search_query': search_query,
    'custom_range': custom_range}
    return render(request, 'users/profiles.html', context)

def search_profiles(request):
    # for htmx
    profiles, search_query = searchProfiles(request)
    custom_range, profiles = paginateObjects(request, 
        profiles, 3)

    context = {
        'profiles': profiles, 
        'search_query': search_query,
        'custom_range': custom_range
    }

    return render(request, 'partials/profiles_list.html', context)
    
def loginUser(request):

    if request.user.is_authenticated:
        return redirect('profiles')

    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        try:
            user = User.objects.get(username=username)
        except:
            messages.error(request, 
                'Такого пользователя нет в системе')

        user = authenticate(request, 
            username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect(request.GET['next'] if 'next' 
                in request.GET else 'profiles')

        else:
            messages.error(request, 
                'Неверное имя пользователя или пароль')

    return render(request, 'users/login_register.html')


def logoutUser(request):
    logout(request)
    # messages.info(request, 'Вы вышли из учетной записи')
    return redirect('login')

      
def verify_email(request, uidb64, token):
    try:
        uid = force_str(urlsafe_base64_decode(uidb64))
        user = User.objects.get(pk=uid)
    except (TypeError, ValueError, OverflowError, User.DoesNotExist):
        user = None

    if user and default_token_generator.check_token(user, token):
        user.is_active = True
        user.save()
        login(request, user)
        return redirect("login")
    else:
        return redirect("login")

def registerUser(request):
    page = 'register'
    form = CustomUserCreationForm()

    if request.method == 'POST':
        email = request.POST.get('email', '').strip()
        if not email.endswith('@sberbank.ru'):
            messages.error(request, 'Регистрация доступна только для почты с доменом @sberbank.ru.')
            return render(request, 'users/login_register.html', {'page': page, 'form': form})

        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()

            token = default_token_generator.make_token(user)
            uid = urlsafe_base64_encode(force_bytes(user.pk))
            verification_link = request.build_absolute_uri(
                reverse("verify_email", kwargs={"uidb64": uid, "token": token})
            )
            # print('registerUser')
            # print(verification_link)

            from foodjob.settings import EMAIL_HOST, EMAIL_HOST_PASSWORD, EMAIL_HOST_PORT, EMAIL_HOST_PROVIDER, EMAIL_HOST_USER,EMAIL_USE_TLS
            # print(EMAIL_HOST, EMAIL_HOST_PASSWORD, EMAIL_HOST_PORT, EMAIL_HOST_PROVIDER, EMAIL_HOST_USER,EMAIL_USE_TLS)
            send_mail(
                "Подтверждение регистрации на СберКусь!",
                f'Перейдите по этой ссылке, чтобы подтвердить вашу почту: {verification_link}',
                EMAIL_HOST_USER,
                [user.email],
                fail_silently=False,
                html_message=f'<h1>Добро пожаловать на СберКусь!</h1>\
                    <p>Перейдите по этой ссылке, чтобы подтвердить вашу почту: {verification_link}</p>',
            )
            messages.success(request, 
                'На указанную почту выслано письмо для подтверждения регистрации')
            return redirect("login")

        else:
            messages.success(request, 
                'Во время регистрации возникла ошибка')
    else:
        form = CustomUserCreationForm()

    context = {'page': page, 'form': form}

    return render(request, 
        'users/login_register.html', context)

def userProfile(request, username):
    profile = Profile.objects.get(username=username)
    interests = profile.interest_set.all()
    # profiles = profile.follows.all()

    # custom_range, profiles = paginateObjects(request, 
    #     profiles, 3)
    
    context = {'profile': profile,
    #  'profiles': profiles,
               'interests': interests,
            #    'custom_range': custom_range
               }

    return render(request, 
        'users/user-profile.html', context)

@login_required 
def profiles_by_interest(request, interest_slug):
    interest = Interest.objects.filter(slug__icontains=interest_slug)
    profiles = Profile.objects.exclude(user=request.user).distinct().filter(
        Q(interest__in=interest))
    context = {'profiles': profiles}

    return render(request, 'users/profiles.html', context)

@login_required
def userAccount(request):
    profile = request.user.profile
    interests = profile.interest_set.all()
    
    # profiles = profile.follows.all()
    # custom_range, profiles = paginateObjects(request, 
    #     profiles, 3)

    context = {'profile': profile,
    #  'profiles': profiles,
    'interests': interests, 
    # 'custom_range': custom_range
    } 
    return render(request, 'users/account.html', context)



@login_required
def editAccount(request):
    profile = request.user.profile
    form = ProfileForm(instance=profile)

    if request.method == 'POST':
        form = ProfileForm(request.POST, request.FILES, 
            instance=profile)
        if form.is_valid():
            form.save()

            return redirect('account')
    context = {'form': form}
 
    return render(request, 
        'users/profile_form.html', context)


@login_required
def createInterest(request):
    profile = request.user.profile
    form = InterestForm()

    if request.method == 'POST':
        form = InterestForm(request.POST)
        if form.is_valid():
            interest = form.save(commit=False)
            interest.description = request.POST.get('description')
            interest.profile = profile
            try:
                interest.save()
                return redirect('account')
            except IntegrityError:
                form.add_error('name', 'У вас уже есть интерес с таким именем и слагом')

    context = {'form': form}
    return render(request, 'users/interest_form.html', context)


@login_required
def updateInterest(request, interest_slug):
    profile = request.user.profile
    interest = profile.interest_set.get(slug=interest_slug)
    form = InterestForm(instance=interest)

    if request.method == 'POST':
        form = InterestForm(request.POST, instance=interest)
        if form.is_valid():
            form.save()
            messages.success(request, 
                'Интерес успешно обновлен')
            return redirect('account')

    context = {'form': form}
    return render(request, 
        'users/interest_form.html', context)


@login_required
def deleteInterest(request, interest_slug):
    profile = request.user.profile
    interest = profile.interest_set.get(slug=interest_slug)
    if request.method == 'POST':
        interest.delete()
        messages.success(request, 'Интерес успешно удален')
        return redirect('account')

    context = {'object': interest}
    return render(request, 'delete_template.html', context)


@login_required
def inbox(request):
    profile = request.user.profile
    messageRequests = profile.messages.all()
    unreadCount = messageRequests.filter(is_read=False).count()
    context = {'messageRequests': messageRequests, 
    'unreadCount': unreadCount}
    return render(request, 'users/inbox.html', context)


@login_required
def viewMessage(request, pk):
    profile = request.user.profile
    message = profile.messages.get(id=pk)
    if message.is_read is False:
        message.is_read = True
        message.save()
    context = {'message': message}
    return render(request, 'users/message.html', context)



def createMessage(request, username):
    recipient = Profile.objects.get(username=username)
    form = MessageForm()

    try:
        sender = request.user.profile
    except:
        sender = None

    if request.method == 'POST':
        form = MessageForm(request.POST)
        if form.is_valid():
            message = form.save(commit=False)
            message.sender = sender
            message.recipient = recipient

            if sender:
                message.name = sender.name
                message.email = sender.email
            message.save()

            messages.success(request, 
                'Сообщение успешно отправлено!')
            return redirect('user-profile', 
                username=recipient.username)

    context = {'recipient': recipient, 'form': form}
    return render(request, 
        'users/message_form.html', context)    

@login_required
def follow_unfollow(request, username):
    profile = Profile.objects.get(username=username)
    if request.method == 'POST':
        current_user_profile = request.user.profile
        data = request.POST
        action = data.get('follow')
        if action == 'follow':
            current_user_profile.follows.add(profile)
            return HttpResponseRedirect(request.META.get('HTTP_REFERER'))
        elif action == 'unfollow':
            current_user_profile.follows.remove(profile)
        current_user_profile.save()
        return HttpResponseRedirect(request.META.get('HTTP_REFERER'))