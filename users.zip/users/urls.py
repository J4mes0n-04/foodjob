from django.urls import path
from . import views
from django.core.mail import send_mail

urlpatterns = [

    path('', views.landing, name='landing'),
    path('landing/', views.landingLogin, name='landingLogin'),
    path('login/', views.loginUser, name='login'),
    path('logout/', views.logoutUser, name='logout'),
    path('register/', views.registerUser, name='register'),
    path("verify/<uidb64>/<token>/", views.verify_email, name="verify_email"),

    path('profiles/', views.profiles, name='profiles'),
    path('profile/<str:username>/', views.userProfile, 
        name='user-profile'),
    path('search_profiles/', views.search_profiles, name='search_profiles'),

    path('account/', views.userAccount, name='account'),
    path('edit-account/', views.editAccount, 
        name='edit-account'),
    path('team/', views.team, name='team'),    
    # path('mail', views.test_mail, name='mail'),           
]