from .models import Profile, Interest
from menu.models import Tags
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from django.db.models import Q


def paginateObjects(request, objects, results):
    page = request.GET.get('page')
    paginator = Paginator(objects, results)

    try:
        objects = paginator.page(page)
    except PageNotAnInteger:
        page = 1
        objects = paginator.page(page)
    except EmptyPage:
        page = paginator.num_pages
        objects = paginator.page(page)

    leftIndex = (int(page) - 4)

    if leftIndex < 1:
        leftIndex = 1

    rightIndex = (int(page) + 5)

    if rightIndex > paginator.num_pages:
        rightIndex = paginator.num_pages + 1

    custom_range = range(leftIndex, rightIndex)

    return custom_range, objects


def searchProfiles(request):
    search_query = request.GET.get('search_query', '')

    interest = Interest.objects.filter(name__icontains=search_query)
    tags = Tags.objects.filter(name__icontains=search_query)

    menu_profiles = Profile.objects.filter(
        Q(menu__dish_name__icontains=search_query, menu__available=True) |
        Q(menu__tags__in=tags, menu__available=True)
    )
    profile_filter = Q(name__icontains=search_query) | \
                     Q(summary__icontains=search_query) | \
                     Q(interest__in=interest) | \
                     Q(id__in=menu_profiles.values_list('id', flat=True))

    if request.user.is_authenticated:
        profiles = Profile.objects.exclude(user=request.user).filter(profile_filter).distinct()
    else:
        profiles = Profile.objects.filter(profile_filter).distinct()

    return profiles, search_query

