from django.contrib.auth import login
from django.contrib.auth.models import User

class GuestLoginMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        # Если пользователь не авторизован
        if not request.user.is_authenticated:
            try:
                # Найдите пользователя guest
                guest_user = User.objects.get(username='guest')
                # Выполните вход
                login(request, guest_user)
            except User.DoesNotExist:
                pass  # Если guest не найден, ничего не делаем

        # Передайте запрос следующему middleware
        response = self.get_response(request)
        return response
