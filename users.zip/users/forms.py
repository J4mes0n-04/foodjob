from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Profile, Interest, Message
from django.forms import ModelForm, FileInput, ModelChoiceField, TextInput, CharField,EmailField,PasswordInput, ValidationError
from bonus.models import Bonus_System, Bonus_type

class CustomUserCreationForm(ModelForm):
    email = EmailField(required=True)
    password1 = CharField(
        label="Пароль",
        widget=PasswordInput(attrs={'class': 'form-control'}),
    )

    class Meta:
        model = User
        fields = ('email', 'password1')
        labels = {
            'email': 'Email', 
            'password1':'Пароль', 
        }

    # password2=None

    # def clean(self):
    #     cleaned_data = super().clean()
    #     # Убираем проверку пароля 2, так как его нет
    #     cleaned_data.pop("password2", None)
    #     return cleaned_data

    def clean_email(self):
        email = self.cleaned_data.get("email")
        if User.objects.filter(email=email, is_active=True).exists() :
            raise ValidationError("Email is already in use by active account.")
        return email
        
    def save(self, commit=True):
        email = self.cleaned_data["email"]
        password = self.cleaned_data["password1"]

        # либо создаем пользователя, либо используем уже существующего
        try:
            user = User.objects.get(email=email)
        except User.DoesNotExist:
            user = super().save(commit=False)
            user.username = email

        user.email = email
        user.set_password(password)
        user.is_active = False

        if commit:
            user.save()
        return user

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # self.fields.pop("password2", None)

        for name, field in self.fields.items():
            field.widget.attrs.update({'class': 'form-control input-box form-ensurance-header-control'})

class ProfileForm(ModelForm):
    bonus_type = ModelChoiceField(
        queryset=Bonus_type.objects.all(),
        label="Тип бонусной системы",
        required=False,
    )
    bonus_parameter = CharField(
        label="Параметр бонусной системы",
        required=False,
        widget=TextInput(attrs={'class': 'form-control'}),
    )

    class Meta:
        model = Profile
        fields = ['name', 'email', 'username', 'summary'
                  , 'about', 'image', 'location', 'website']

        labels = {
            'name': 'Название партнера',
            'email': 'Email', 
            'username':'Логин',
            'location': 'Расположение', 
            'summary': 'В двух словах о себе',
            'about': 'Подробнее о себе',
            'image': 'Изменить фото профиля',
            'website': 'Сайт',
        }


    def __init__(self, *args, **kwargs):
        super(ProfileForm, self).__init__(*args, **kwargs)
        for name, field in self.fields.items():
            field.widget.attrs.update({'class': 'form-control input-box form-ensurance-header-control'})

    def save(self, commit=True):
        profile = super().save(commit=False)
        if commit:
            profile.save()
            bonus_type = self.cleaned_data.get('bonus_type')
            bonus_parameter = self.cleaned_data.get('bonus_parameter')
            if bonus_type and bonus_parameter:
                # rule = {}
                rule = {"type": bonus_type.bonus_name, "n": float(bonus_parameter)}
                # if bonus_type.bonus_name == "percentage_cashback":
                #     rule = {"type": "percentage_cashback", "percentage": float(bonus_parameter)}
                # elif bonus_type.bonus_name == "free_item_after_n_purchases":
                #     rule = {"type": "free_item_after_n_purchases", "n": int(bonus_parameter)}
                #TODO: У заведения может быть больше 1 системы бонусов. Нужно добавить возможность выключать не нужные бонусные системы
            Bonus_System.objects.update_or_create(
                place=profile,  # Условие поиска: запись для этого заведения
                bonus_type = bonus_type,
                is_active =  True, 
                defaults={
                    "bonus_type": bonus_type,  # Обновляем тип бонуса
                    "rule": rule  # Обновляем правило
                }
            )
        return profile


# class ProfileForm(ModelForm):
#     class Meta:
#         model = Profile
#         fields = ['name', 'email', 'username',
#                   'summary', 'about', 'image', 
#                   'location', 
#                     'website',]
#         labels = {
#             'name': 'Название партнера',
#             'email': 'Email', 
#             'username':'Логин',
#             'location': 'Расположение', 
#             'summary': 'В двух словах о себе',
#             'about': 'Подробнее о себе',
#             'image': 'Изменить фото профиля',
#             'website': 'Сайт',
#         }
#         widgets = {
#             'image': FileInput(),
#         }
#     def __init__(self, *args, **kwargs):
#         super(ProfileForm, self).__init__(*args, **kwargs)

#         for name, field in self.fields.items():
#             field.widget.attrs.update({'class': 'form-control input-box form-ensurance-header-control'})
                

class InterestForm(ModelForm):
    class Meta:
        model = Interest
        fields = '__all__'
        exclude = ['profile', 'slug']

        labels = {
            'name': 'Название',
            'description':'Описание',
          
        }

    def __init__(self, *args, **kwargs):
        super(InterestForm, self).__init__(*args, **kwargs)

        for name, field in self.fields.items():
            field.widget.attrs.update({'class': 'form-control input-box form-ensurance-header-control'})




class MessageForm(ModelForm):
    class Meta:
        model = Message
        fields = ['name', 'email', 'subject', 'body']
        labels = {'name': 'Имя и фамилия',
            'email': 'Email', 
            'subject':'Тема сообщения',
            'body':'Текст сообщения'
        }

    def __init__(self, *args, **kwargs):
        super(MessageForm, self).__init__(*args, **kwargs)

        for name, field in self.fields.items():
            field.widget.attrs.update({'class': 'form-control input-box form-ensurance-header-control'})
