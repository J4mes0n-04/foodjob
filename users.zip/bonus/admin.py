from django.contrib import admin
from .models import Bonus_type

# Register your models here.
admin.site.register(Bonus_type)