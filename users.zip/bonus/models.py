from django.db import models
from django.contrib.auth.models import User

from django.utils import timezone

from users.models import Profile

# Create your models here.
class Bonus_type(models.Model):
    bonus_name = models.CharField(max_length=150)

    def __str__(self):
        return self.bonus_name
    class Meta:
        verbose_name = ("Виды бонусов")
        verbose_name_plural = ("Справочник видов бонусов")

class Bonus_System(models.Model):
    place = models.ForeignKey(Profile, on_delete=models.CASCADE)
    bonus_type = models.ForeignKey(Bonus_type, on_delete=models.SET_NULL, null=True,blank=True)
    rule = models.JSONField(default=dict)

    valid_from = models.DateField(
        verbose_name="Действует с",
        default=timezone.now,
        help_text="Дата начала действия бонусной системы"
    )
    valid_to = models.DateField(
        verbose_name="Действует до",
        default=timezone.datetime.strptime('2999-01-01', '%Y-%m-%d').date(),
        help_text="Дата окончания действия (по умолчанию 2999-01-01)"
    )
    is_active = models.BooleanField(
        verbose_name="Активна",
        default=True,
        help_text="Флаг активности бонусной системы"
    )
    class Meta:
        verbose_name = ("Система бонусов")
        verbose_name_plural = ("Системы бонусов")

#get_or_create
class User_Bonus(models.Model):
    bonus_cnt = models.IntegerField(default=0, blank=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, blank=True)
    place = models.ForeignKey(Profile, on_delete=models.CASCADE, blank=True)
    bonus_system = models.ForeignKey(Bonus_System, on_delete=models.CASCADE, blank=True)

    class Meta:
        unique_together = ('user', 'place', 'bonus_system')

    def add_bonus(self, purchase_amount):
        """
        Добавляет бонусы в зависимости от правила бонусной системы.
        :param purchase_amount: сумма покупки, на основе которой рассчитываются бонусы.
        """
        # Получаем бонусную систему, связанную с заведением
        bonus_system = Bonus_System.objects.filter(place=self.place
                                                   , pk=self.bonus_system.pk
                                                   , is_active=True).first()
        if not bonus_system:
            return "Бонусная система для этого заведения не найдена."

        rule = bonus_system.rule  # Получаем JSON-правило

        # Обрабатываем правило в зависимости от его типа
        bonus_type = rule.get("type")

        if bonus_type == "free_item_after_n_purchases":
            # Пример: 6-ой напиток бесплатно
            n = rule.get("n")
            if self.bonus_cnt >= n:
                # self.bonus_cnt = 0  # Сбрасываем счетчик после начисления бонуса
                self.bonus_cnt += 1
                self.save()
                return f"{self.bonus_cnt}. Можно получить бесплатный напиток!"
            self.bonus_cnt += 1
            self.save()
            return self.bonus_cnt

        elif bonus_type == "percentage_cashback":
            #% с каждой покупки начисляется на баланс клиента
            percentage = rule.get("n")
            bonus_points = float(purchase_amount) * (percentage / 100)
            self.bonus_cnt += bonus_points
            self.save()
            return self.bonus_cnt

        elif bonus_type == "fixed_cashback":
            #Фиксированный кэшбек 
            fixed_amount = rule.get("n")
            self.bonus_cnt += fixed_amount
            self.save()
            return self.bonus_cnt
        
        else:
            raise ValueError(f"Неизвестный тип бонусной системы: {bonus_type}")