from django.forms import EmailField, DecimalField, Form , ModelChoiceField, EmailInput, Select, NumberInput
from bonus.models import Bonus_System, Bonus_type

# from django import forms


class PartnerBonusAdd(Form):
    def __init__(self, *args, place=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.place = place
        
        # Фильтруем типы бонусов только для активных систем текущего заведения
        if place:
            active_bonus_systems = Bonus_System.objects.filter(
                place=place,
                is_active=True
            )
            self.fields['bonus_type'].queryset = Bonus_type.objects.filter(
                bonus_system__in=active_bonus_systems
            ).distinct()

    user_email = EmailField(
        label='Email пользователя',
        widget=EmailInput(attrs={'class': 'form-control input-box form-ensurance-header-control'})
    )
    
    purchase_amount = DecimalField(
        label='Сумма покупки',
        widget= NumberInput(attrs={'class': 'form-control input-box form-ensurance-header-control'}),
        min_value=0.01,
        max_digits=10,
        decimal_places=2
    )
    
    bonus_type = ModelChoiceField(
        queryset=Bonus_type.objects.none(),  # Начально пустой queryset
        label="Тип бонусной системы",
        required=False,
        widget= Select(attrs={'class': 'form-control input-box form-ensurance-header-control'})
    )
    class Meta:
        fields = ('user_id', 'purchase_amount', 'bonus_type')
        labels = {
            'user_id': 'Mail пользователя', 
            'purchase_amount':'Сумма покупки',
            'bonus_type': 'Тип бонусной системы',
        }

        

