from django.urls import path
from . import views
from django.conf.urls.static import static
from django.conf import settings

app_name = "bonus"

urlpatterns = [
    path('bonus/<str:place_id>', views.partner_bonus_screen, name="partner_bonus_screen"),
    path('user_bonus/', views.user_bonus_screen, name='user_bonus'),
    path('user_bonus/<int:place_id>/', views.user_bonus_detail, name='user_bonus_detail'),
]
urlpatterns += static(settings.STATIC_URL,document_root=settings.STATIC_ROOT)