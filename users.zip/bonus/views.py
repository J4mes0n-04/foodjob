from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django import urls


from .forms import PartnerBonusAdd
from users.models import Profile
from bonus.models import User_Bonus, Bonus_System, Bonus_type


# Create your views here.

def partner_bonus_screen(request, place_id):
    place = get_object_or_404(Profile, id=place_id)

    if request.method == 'POST':
        form = PartnerBonusAdd(request.POST, place=place)
        if form.is_valid():
            user_email = form.cleaned_data['user_email']
            purchase_amount = form.cleaned_data['purchase_amount']
            bonus_type_name = form.cleaned_data['bonus_type']
            
            try:
                user = User.objects.get(email=user_email)

                bonus_system = Bonus_System.objects.get(
                    place=place,
                    bonus_type__bonus_name=bonus_type_name,
                    is_active=True
                )

                print(bonus_system)

                # Получаем или создаём запись о бонусах
                user_bonus, _ = User_Bonus.objects.get_or_create(
                    user=user,
                    place=place,
                    bonus_system =bonus_system,
                    defaults={'bonus_cnt': 0}
                )
                 # Добавляем бонусы
                current_bonus = user_bonus.add_bonus(purchase_amount)
                
                messages.success(
                    request,
                    f'Бонусы успешно начислены! Текущий баланс: {current_bonus}'
                )
                # return redirect(urls.reverse('partner_bonus_screen'), place_id=place_id)
            except User.DoesNotExist:
                messages.error(request, 'Пользователь с таким email не найден')
    else:
        form = PartnerBonusAdd(place=place)
    
    context = {
        'form': form,
        'place': place,
    }
    return render(request, 'partner_bonus.html', context)
    
#   2. Кол-во бонусов у клиента

@login_required
def user_bonus_screen(request):
    # Получаем все заведения, где у пользователя есть бонусы
    places = Profile.objects.filter(
        user_bonus__user=request.user,
        user_bonus__bonus_system__is_active=True
    ).distinct()
    
    context = {
        'places': places,
    }
    return render(request, 'user_bonus_all.html', context)

@login_required
def user_bonus_detail(request, place_id):
    place = get_object_or_404(Profile, id=place_id)
    
    # Получаем все активные бонусные системы пользователя для этого заведения
    user_bonuses = User_Bonus.objects.filter(
        place=place,
        user=request.user,
        bonus_system__is_active=True
    ).select_related('bonus_system', 'bonus_system__bonus_type')
    
    context = {
        'place': place,
        'user_bonuses': user_bonuses,
    }
    return render(request, 'user_bonus_screen.html', context)