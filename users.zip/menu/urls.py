from django.urls import path
from . import views
from django.conf.urls.static import static
from django.conf import settings

app_name = "menu"

urlpatterns = [
    path('menu/<str:place_id>', views.menu_main_show, name="menu_main"),
    path('menu/upload/<int:place_id>/', views.upload_menu_file, name='upload_menu_file'),
    path('menu/<str:place_id>/tag/<int:tag_id>', views.menu_by_tag, name="menu_by_tag"),

    # htmx partials
    path('partials/toggle-like-menu/<int:menu_item>/', views.toggle_like_menu, name='toggle-like-menu'),
]
urlpatterns += static(settings.STATIC_URL,document_root=settings.STATIC_ROOT)
