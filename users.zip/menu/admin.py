from django.contrib import admin
from .models import Menu, Category, Tags

# Register your models here.
admin.site.register(Category)
admin.site.register(Menu)
admin.site.register(Tags)
