from django.db import models
from django.contrib.auth.models import User
from users.models import Profile
from pytils.translit import slugify

class Category(models.Model):
    name = models.CharField(max_length=255)
    sort = models.IntegerField(default=0, blank=True, null=True)
    def __str__(self):
        return self.name
    
class Tags(models.Model):
    name = models.CharField(max_length=255)
    slug = models.SlugField(blank=True, null=True)

    def save(self, *args, **kwargs):
        value = self.name
        self.slug = slugify(value)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.name

class Menu(models.Model):
    dish_name = models.CharField(max_length=255)
    price = models.DecimalField(max_digits=6, decimal_places=2, default=0)
    description = models.TextField(blank=True, null=True)
    place = models.ForeignKey(
        Profile, null=True, blank=True, on_delete=models.CASCADE
    )
    category = models.ForeignKey( 
        Category, null=True, blank=True, on_delete=models.CASCADE
    )
    available = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add = True)   
    tags = models.ManyToManyField(Tags, blank=True)
    callories = models.DecimalField(max_digits=4, decimal_places=2, blank= True, null=True)
    protein = models.DecimalField(max_digits=4, decimal_places=2,blank= True, null=True)
    fat = models.DecimalField(max_digits=4, decimal_places=2,blank= True, null=True)
    carbohydrates = models.DecimalField(max_digits=4, decimal_places=2, blank= True, null=True)
    source = models.CharField(db_index=True, blank=True, null= True, max_length=255)
    likes = models.ManyToManyField(User, related_name = 'menu_item_likes')
    is_business_lunch = models.BooleanField(default=False, db_column='is_business_lunch')
    loaded_name = models.CharField(max_length=255)
    weight = models.CharField(max_length=255)
    week_day= models.IntegerField(default=0, blank=True, null=True)

    @staticmethod
    def get_available_menu_from_place(place, week_day):
        """
        Возвращает доступное меню для указанного заведения.
        """
        return Menu.objects.filter(place=place, available=True, week_day=week_day) \
            .order_by('category') \
            .distinct('place','category','dish_name','price',)
    
    def number_of_likes(self):
        if self.likes.count() == 0:
            return ''
        else:
            return self.likes.count()
    
    def __str__(self):
        return self.dish_name

class MenuItemLikes(models.Model):
    user = models.ForeignKey(User, models.DO_NOTHING, db_column= 'user_id')
    menu_item = models.ForeignKey(Menu, models.DO_NOTHING)
    create_at = models.DateField(auto_now_add = True, db_column= 'create_at')

    class Meta:
        managed = False
        db_table = 'menu_menu_likes'