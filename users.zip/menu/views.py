from django.shortcuts import render, get_object_or_404 , redirect
from .models import Menu, Profile, Category, Tags, MenuItemLikes
from django.contrib.auth.decorators import login_required
from .forms import UploadFileForm
from django.utils import timezone
from django.db.models import Prefetch
from openpyxl import load_workbook
from .utils import upload_menu_keyterinburg, get_week_day

# Create your views here.

def menu_main_show(request,place_id):
    place = get_object_or_404(Profile, id=place_id)#Отдает ошибку если нет заведения
    profile = Profile.objects.get(id=place_id)
    week_day=get_week_day()

    menu_items = Menu.get_available_menu_from_place(place=place_id, week_day=week_day)
    category_id = request.GET.get('category')  # Получаем выбранную категорию из GET-запроса
    categories = Category.objects.filter(menu__place=place, menu__available=True, menu__week_day=week_day).distinct().order_by("sort")    # Все категории, в которых есть блюда

    
    menu_items = Menu.objects.prefetch_related(Prefetch('tags', queryset=Tags.objects.all())).filter(place=place, week_day=week_day).order_by("dish_name")

    # Извлекаем все теги из предзагруженных меню
    tags = set(tag for menu in menu_items for tag in menu.tags.all())
    tag_id=None

    # Фильтруем меню по категории (если категория выбрана)
    if category_id:
        menu_items = Menu.objects.filter(place=place, available=True, category_id=category_id, week_day=week_day)\
            .distinct('place','category','dish_name','price',)
    else:
        menu_items = Menu.get_available_menu_from_place(place=place_id, week_day=week_day)  # Все доступные блюда

    context = {
        'menu_items': menu_items,
        'place': place,
        'categories': categories,
        'selected_category': category_id, 
        'profile': profile,
        'tags': tags,
        'selected_tag': tag_id,
    }    
    return render(request, 'menu_main.html',context)

def menu_by_tag(request, place_id, tag_id):
    place = get_object_or_404(Profile, id=place_id)
    profile = Profile.objects.get(id=place_id)
    week_day=get_week_day()

    selected_tag = int(tag_id) if tag_id else None
    
    tags = Tags.objects.filter(menu__place=place).distinct()
    categories = Category.objects.filter(menu__place=place, menu__available=True, menu__tags__id=tag_id, menu__week_day=week_day).distinct()
    
    category_id = request.GET.get('category')  # Получаем выбранную категорию из GET-запроса

    if category_id:
        menu_items = Menu.objects.filter(place=place, available=True, category_id=category_id,tags__id=tag_id, week_day=week_day)\
            .distinct('place','category','dish_name','price',)
    else:
        # Все доступные блюда
        menu_items = Menu.objects.filter(place=place, available=True, tags__id=tag_id, week_day=week_day)\
       .distinct('place','category','dish_name','price',).order_by('category')

    context = {
        'menu_items': menu_items,
        'place': place,
        'categories': categories,
        'selected_category': category_id,
        'profile': profile,
        'tags': tags,
        'selected_tag': tag_id,
    }
    return render(request,'menu_main.html', context)


@login_required
def upload_menu_file(request, place_id):
    place = get_object_or_404(Profile, id=place_id)
    if request.method == "POST":
        form = UploadFileForm(request.POST, request.FILES)
        if form.is_valid():
            file = request.FILES['file']
            upload_menu_keyterinburg(file, place)
            return redirect('menu:menu_main', place_id=place_id)
    else:
        form = UploadFileForm()

    return render(request, 'upload_menu.html', {'form': form, 'place': place})

def toggle_like_menu(request, menu_item):
    # for htmx
    menu_item = get_object_or_404(Menu, id=menu_item)
    if request.user:
        liked=menu_item.likes.filter(id=request.user.id).exists()
        if request.method == "POST":
            if liked:
                menu_item.likes.remove(request.user)
                liked=False
            else:
                menu_item.likes.add(request.user)
                liked=True
            menu_item.save() 
    else:
        liked=False
        
    # Return updated button HTML
    return render(request, "partials/like_button_2.html", {"item":menu_item,"liked": liked})
