from django.forms import ModelForm
from django import forms
from .models import Menu, Category

from django import forms

class UploadFileForm(forms.Form):
    file = forms.FileField(label="Загрузите файл (.xls)")