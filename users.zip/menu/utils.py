import re
from django.utils.text import slugify
from .models import Menu, Category, Tags
from openpyxl import load_workbook
from datetime import datetime, timedelta

def clean_loaded_name(name):
    # Удаляем * и (ПФ)/(П)
    name = name.strip().lstrip("*").strip()
    name = re.sub(r"\(ПФ?\)", "", name, flags=re.IGNORECASE).strip()

    # Удаляем вес в формате: 100г, 100 г, 75/50 г, 90/60/30гр.
    name = re.sub(r"(\d+(/\d+)*\s*г[р.]?\.*)$", "", name, flags=re.IGNORECASE).strip()

    # Удаляем одиночное число в конце, например: "Курица отварная 100"
    name = re.sub(r"\b\d{2,4}$", "", name).strip()

    return name.lower()
import re
from openpyxl import load_workbook

# Очистка названия группы для создания тега
def clear_tag_name(group_name):
    if not group_name:
        return ""

    name = group_name.strip().lower()

    # Удаляем известные мусорные фразы
    name = re.sub(r"сложное\s+основное\s+куриное\s+блюдо", "", name)

    # Убираем пробелы, пример: "ЛАНЧ 2" -> "ланч2"
    name = re.sub(r"\s+", "", name)

    return name.strip()


# Загрузка Excel меню с конкретной структурой
def upload_menu_foodstore(file, place):
    wb = load_workbook(file, read_only=True, data_only=True)

    # Находим последний лист, имя которого — только цифры и точки (например, "18.06")
    date_sheet_name = None
    for name in reversed(wb.sheetnames):
        if re.match(r"^\d{1,2}\.\d{1,2}$", name.strip()):
            date_sheet_name = name
            break

    if not date_sheet_name:
        raise ValueError("Не найден лист с датой в формате дд.мм")

    sheet = wb[date_sheet_name]

    current_category = None
    found_loaded_names = set()

    for row in sheet.iter_rows(min_row=2, values_only=True):
        group, code, name, weight, cost_field, count, price = row[:7]

        # Если и код, и наименование отсутствуют — это категория
        if not code and not name and group:
            category_obj, _ = Category.objects.get_or_create(name=group.strip())
            current_category = category_obj
            continue

        if not name:
            continue

        # Обработка имени блюда
        dish_name_raw = str(name).strip()
        loaded_name = dish_name_raw.lower()
        found_loaded_names.add(loaded_name)

        # Обработка веса: убираем "г", "порция" и пробелы
        weight_clean = None
        if weight:
            weight_clean = re.sub(r"(порц(ия|ии)?|[гГ.])", "", str(weight)).strip()

        # Обработка цены
        try:
            price_val = float(price)
        except (ValueError, TypeError):
            price_val = 0

        # Поиск и обновление/создание блюда
        menu_item = Menu.objects.filter(loaded_name=loaded_name, place=place).first()

        if menu_item:
            menu_item.available = True
            menu_item.price = price_val
            if current_category:
                menu_item.category = current_category
            menu_item.save()
        else:
            menu_item = Menu.objects.create(
                dish_name=loaded_name.capitalize(),
                loaded_name=loaded_name,
                place=place,
                category=current_category,
                price=price_val,
                weight=weight_clean,
                available=True,
            )

        # Привязка тега
        tag_name_clean = clear_tag_name(group)
        if tag_name_clean:
            tag, _ = Tags.objects.get_or_create(name=tag_name_clean)
            menu_item.tags.add(tag)

    # Отмечаем как недоступные все отсутствующие блюда
    Menu.objects.filter(place=place).exclude(loaded_name__in=found_loaded_names).update(available=False)

def upload_menu_keyterinburg(file, place):
    
    wb = load_workbook(file, read_only=True, data_only=True)
    sheet = wb[wb.sheetnames[-1]]

    current_category = None
    found_loaded_names = set()

    for row in sheet.iter_rows(min_row=2, values_only=True):
        label, name, weight, count, note = row[:5]

        # Категория — если нет веса и количества
        if weight is None and count is None and name:
            category_obj, _ = Category.objects.get_or_create(name=name.strip())
            current_category = category_obj
            continue

        if not name or weight is None or count is None:
            continue

        loaded_name = clean_loaded_name(name)
        found_loaded_names.add(loaded_name)

        is_lunch = bool(label and "ланч" in str(label).lower())

        # Получаем или создаём объект по loaded_name
        menu_item = Menu.objects.filter(loaded_name=loaded_name, place=place).first()

        if menu_item:
            # Обновление существующего
            menu_item.available = True
            menu_item.is_business_lunch = is_lunch
            if current_category:
                menu_item.category = current_category
            menu_item.save()
        else:
            # Создание нового
            menu_item = Menu.objects.create(
                dish_name=loaded_name.capitalize(),
                loaded_name=loaded_name,
                place=place,
                category=current_category,
                price=0,
                available=True,
                weight=weight,
                is_business_lunch=is_lunch
            )

        # Привязка тега из label
        if label:
            tag_name = str(label).strip().lower()
            tag, _ = Tags.objects.get_or_create(name=tag_name)
            menu_item.tags.add(tag)

    # Отмечаем как unavailable блюда, не встреченные в этом файле
    Menu.objects.filter(place=place).exclude(loaded_name__in=found_loaded_names).update(available=False)

def get_week_day(date_str=None):
    """
    Формирует week_day по текущей дате в формате: день_недели + номер_недели
    
    Параметры:
    date_str (str, optional): Дата в формате 'DD.MM.YYYY'. Если None, используется текущая дата.
    
    Возвращает:
    int: Число в формате XY, где X - номер недели (1-4), Y - день недели (1-7, понедельник=1)
    """
    if date_str:
        date = datetime.strptime(date_str, '%d.%m.%Y')
    else:
        date = datetime.now()

    # День недели (1-7, понедельник=1)
    day_of_week = date.isoweekday()

     # если смотрит в субботу или воскресенье
    if day_of_week in [6, 7]:
        # показываем расписание на понедельник
        days_until_monday = 8 - day_of_week
        date += timedelta(days=days_until_monday)
        day_of_week=1

    # Отсчет ведем от 30 июня 2025 - это 1 день 1 недели
    base_date=datetime.strptime('30.06.2025', '%d.%m.%Y')

    # разница в 28 дневных отрезках
    delta=(date-base_date).days % 28

    # и какая это неделя отрезка? с 1 по 4
    week=delta//7+1

    return week*10+day_of_week