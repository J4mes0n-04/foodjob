from django.urls import path
from . import views

app_name = "blog"

urlpatterns = [
    path('myblog/', views.myBlog, name="my-blog"),

    path('blog/<str:username>/', views.userBlog, name="user-blog"),
    path('post/<slug:post_slug>/', views.post, name="post"),
    # path('posts/<str:username>/', views.posts_by_username, name="posts"),

    path('category/', views.posts_by_category, name="category_all"),
    path('category/<slug:category_slug>/', views.posts_by_category, name="by_category"),
    path('tag/<slug:tag_slug>', views.posts_by_tag, name="by_tag"),
    
    path('create-post/', views.createPost, name="create-post"),
    path('update-post/<str:pk>', views.updatePost, name="update-post"),
    path('delete-post/<str:pk>', views.deletePost, name="delete-post"),
    path('like/<int:post_id>', views.like_post, name='like_post'),

    # htmx partials
    path('partials/toggle-like-post/<int:post_id>/', views.toggle_like_post, name='toggle-like-post'),
]