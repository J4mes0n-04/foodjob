from django_mailbox.models import Mailbox, Message
# from utils import send_email
from django.http import HttpResponse
from django.utils import timezone
import psycopg2
from psycopg2 import sql
from  foodjob.settings import DATABASES
import base64
import quopri

def extract_text_between_markers(text, start_marker="##start", end_marker="##end"):
    """
    Вырезает текст между указанными маркерами.
    
    :param text: Строка, из которой нужно вырезать текст.
    :param start_marker: Начальный маркер (по умолчанию '##start##').
    :param end_marker: Конечный маркер (по умолчанию '##end##').
    :return: Текст между маркерами или пустая строка, если маркеры не найдены.
    """
    start_index = text.find(start_marker)
    end_index = text.find(end_marker, start_index + len(start_marker))
    
    if start_index == -1 or end_index == -1:
        return ""  # Если хотя бы один из маркеров не найден
    
    # Получаем текст между маркерами
    return text[start_index + len(start_marker):end_index].strip()

def getMail(request):

    mailboxes = Mailbox.objects.filter(active=True)

    db_default=DATABASES['default']
    conn = psycopg2.connect(
                dbname=db_default['NAME'],
                user=db_default['USER'],
                password=db_default['PASSWORD'],
                host=db_default['HOST'],
                port=db_default['PORT']
            )

    for mailbox in mailboxes:
        new_messages = mailbox.get_new_mail()
    
        for message in new_messages:
            if message.subject=='Новость':
                # вызов обработчика
                # блять я так устал и хочу спать
                try:
                    decoded_text = base64.b64decode(message.body).decode("utf-8", errors="ignore")
                    print(decoded_text)
                    mail_text=extract_text_between_markers(decoded_text)
                    mail_text = quopri.decodestring(mail_text).decode("utf-8")
                    with conn.cursor() as cursor:
                        # SQL запрос с вызовом функции, передающей параметр
                        cursor.execute(
                            sql.SQL("SELECT parse_news(%s);"), [mail_text]
                        )
                        conn.commit()  # если функция изменяет данные в базе
                        print("Функция обработки новости выполнена успешно!")
                except Exception as e:
                    print(f"Ошибка при вызове функции обработки новости : {e}")
                finally:
                    conn.close()
            else:
                # вызов обработчика
                try:
                    decoded_text = base64.b64decode(message.body).decode("utf-8", errors="ignore")
                    mail_text=extract_text_between_markers(decoded_text)
                    mail_text = quopri.decodestring(mail_text).decode("utf-8")
                    print(mail_text)
                    with conn.cursor() as cursor:
                        # SQL запрос с вызовом функции, передающей параметр
                        cursor.execute(
                            sql.SQL("SELECT parse_and_save_email(%s);"), [mail_text]
                        )
                        conn.commit()  # если функция изменяет данные в базе
                        print("Функция обработки меню выполнена успешно!")
                except Exception as e:
                    print(f"Ошибка при вызове функции обработки меню: {e}")
                finally:
                    conn.close()

            if not message.pk:  # Если сообщение не сохранено
                # вызываем функцию парсера для тела
                
                # проставляем флаг, что прочитали, запарсили
                message.read=timezone.now()
                message.save()

            # ответ
        # subject='Message received'
        # body='Your message received successfully'
        # recepient=mailbox.name
        # send_email(subject,body,)
    django_response = HttpResponse(status=200)
    return django_response 
