import smtplib
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from os.path import basename
import os

try:
    EMAIL_HOST_USER=os.getenv('EMAIL_HOST_USER')
    EMAIL_HOST_PASSWORD=os.getenv('EMAIL_HOST_PASSWORD')
    EMAIL_HOST_PORT=os.getenv('EMAIL_HOST_PORT')
    EMAIL_HOST_PROVIDER=os.getenv('EMAIL_HOST_PROVIDER')
    EMAIL_RECIPIENTS=os.getenv('EMAIL_RECIPIENTS')
except:
    # default settings
    EMAIL_HOST_USER = 'a@a.com'
    EMAIL_HOST_PASSWORD = ''
    EMAIL_HOST_PROVIDER='smtp.a.com'
    EMAIL_HOST_PORT=465
    EMAIL_RECIPIENTS = ["default_recepient"]

def send_email(subject, body, recipients, attachment_path='', html_message=''):
    # Create a multipart message if there is an attachment or HTML content
    if attachment_path != '' or html_message != '':
        msg = MIMEMultipart()
        
        # If there's an attachment, attach it
        if attachment_path != '':
            with open(attachment_path, "rb") as attachment:
                filename = basename(attachment_path)
                part = MIMEBase("application", "octet-stream")
                part.set_payload(attachment.read())
                encoders.encode_base64(part)
                part.add_header("Content-Disposition", f"attachment; filename={filename}")
                msg.attach(part)

        # If there is HTML content, attach it
        if html_message != '':
            html_part = MIMEText(html_message, "html")  # Specify that it's HTML
            msg.attach(html_part)

        # If there's no HTML message, just attach the plain text body
        if html_message == '':
            body_part = MIMEText(body, "plain")  # Specify that it's plain text
            msg.attach(body_part)

    else:
        # If no attachment or HTML, just send a plain text message
        msg = MIMEText(body, "plain")

    # Set email headers
    msg['Subject'] = subject
    msg['From'] = EMAIL_HOST_USER
    msg['To'] = ', '.join(recipients)

    # Send the email
    with smtplib.SMTP_SSL(EMAIL_HOST_PROVIDER, EMAIL_HOST_PORT) as smtp_server:
        smtp_server.login(EMAIL_HOST_USER, EMAIL_HOST_PASSWORD)
        smtp_server.sendmail(EMAIL_HOST_USER, recipients, msg.as_string())
    
 