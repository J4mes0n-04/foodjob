from django.urls import path
from .views import getMail

app_name = "mailbot"

urlpatterns = [
    path('get-email/', getMail, name='get-email'),

]