CREATE VIEW user_orders_menu AS        -- Заказ юзера
SELECT 
    users.user_id,                -- Уникальный идентификатор клиента
    users.username,               -- Имя клиента
    orders.order_date,            -- Дата и время оформления заказа
    food_place.name AS restaurant_name,  -- Название ресторана
    menu_items.name AS menu_item_name,   -- название элемента
    menu_items.price                     -- Название элемента меню
FROM 
    users
JOIN 
    orders ON users.user_id = orders.user_id
JOIN 
    order_items ON orders.order_id = order_items.order_id
JOIN 
    menu_items ON order_items.menu_item_id = menu_items.item_id
JOIN 
    food_place ON orders.restaurant_id = food_place.restaurant_id;