CREATE FUNCTION track_order(order_id INT)
RETURNS TABLE(order_status VARCHAR) AS $$
BEGIN
    RETURN QUERY SELECT status FROM orders WHERE order_id = order_id;
END;
$$ LANGUAGE plpgsql;