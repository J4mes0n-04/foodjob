CREATE FUNCTION view_menu(restaurant_id INT)
RETURNS TABLE(menu_item_name VARCHAR, price DECIMAL) AS $$
BEGIN
    RETURN QUERY SELECT name, price FROM menu_items WHERE restaurant_id = restaurant_id;
END;
$$ LANGUAGE plpgsql;