CREATE FUNCTION register_user(username VARCHAR not null, email VARCHAR not null,  password VARCHAR not null, phone varchar not null)
RETURNS VOID AS $$
BEGIN
    INSERT INTO users (username, email, password, phone) VALUES (username, email, password, phone);
END;
$$ LANGUAGE plpgsql;