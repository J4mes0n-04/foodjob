-- Комментарии для таблицы auth_permission
COMMENT ON TABLE auth_permission IS 'Таблица для хранения разрешений (permissions)';
COMMENT ON COLUMN auth_permission.codename IS 'Уникальный код разрешения';
COMMENT ON COLUMN auth_permission.content_type_id IS 'Ссылка на тип контента, к которому относится разрешение';
COMMENT ON COLUMN auth_permission.id IS 'Уникальный идентификатор разрешения';
COMMENT ON COLUMN auth_permission.name IS 'Название разрешения';

-- Комментарии для таблицы auth_group
COMMENT ON TABLE auth_group IS 'Таблица для хранения групп пользователей';
COMMENT ON COLUMN auth_group.id IS 'Уникальный идентификатор группы';
COMMENT ON COLUMN auth_group.name IS 'Название группы';

-- Комментарии для таблицы auth_group_permissions
COMMENT ON TABLE auth_group_permissions IS 'Таблица для связи групп и разрешений';
COMMENT ON COLUMN auth_group_permissions.group_id IS 'Ссылка на группу';
COMMENT ON COLUMN auth_group_permissions.id IS 'Уникальный идентификатор связи группы и разрешения';
COMMENT ON COLUMN auth_group_permissions.permission_id IS 'Ссылка на разрешение';

-- Комментарии для таблицы auth_user
COMMENT ON TABLE auth_user IS 'Таблица для хранения пользователей';
COMMENT ON COLUMN auth_user.id IS 'Уникальный идентификатор пользователя';
COMMENT ON COLUMN auth_user.password IS 'Пароль пользователя';
COMMENT ON COLUMN auth_user.last_login IS 'Дата последнего входа пользователя';
COMMENT ON COLUMN auth_user.is_superuser IS 'Флаг, указывающий, является ли пользователь суперпользователем';
COMMENT ON COLUMN auth_user.username IS 'Имя пользователя (логин)';
COMMENT ON COLUMN auth_user.first_name IS 'Имя пользователя';
COMMENT ON COLUMN auth_user.last_name IS 'Фамилия пользователя';
COMMENT ON COLUMN auth_user.email IS 'Электронная почта пользователя';
COMMENT ON COLUMN auth_user.is_staff IS 'Флаг, указывающий, является ли пользователь сотрудником';
COMMENT ON COLUMN auth_user.is_active IS 'Флаг активности пользователя';
COMMENT ON COLUMN auth_user.date_joined IS 'Дата регистрации пользователя';

-- Комментарии для таблицы auth_user_groups
COMMENT ON TABLE auth_user_groups IS 'Таблица для связи пользователей и групп';
COMMENT ON COLUMN auth_user_groups.id IS 'Уникальный идентификатор связи пользователя и группы';
COMMENT ON COLUMN auth_user_groups.user_id IS 'Ссылка на пользователя';
COMMENT ON COLUMN auth_user_groups.group_id IS 'Ссылка на группу';

-- Комментарии для таблицы auth_user_user_permissions
COMMENT ON TABLE auth_user_user_permissions IS 'Таблица для связи пользователей и разрешений';
COMMENT ON COLUMN auth_user_user_permissions.id IS 'Уникальный идентификатор связи пользователя и разрешения';
COMMENT ON COLUMN auth_user_user_permissions.user_id IS 'Ссылка на пользователя';
COMMENT ON COLUMN auth_user_user_permissions.permission_id IS 'Ссылка на разрешение';

-- Комментарии для таблицы users_message
COMMENT ON TABLE users_message IS 'Таблица для хранения сообщений пользователей';
COMMENT ON COLUMN users_message.id IS 'Уникальный идентификатор сообщения';
COMMENT ON COLUMN users_message.sender_id IS 'Ссылка на отправителя сообщения';
COMMENT ON COLUMN users_message.recipient_id IS 'Ссылка на получателя сообщения';
COMMENT ON COLUMN users_message.subject IS 'Тема сообщения';
COMMENT ON COLUMN users_message.body IS 'Текст сообщения';
COMMENT ON COLUMN users_message.email IS 'Электронная почта отправителя';
COMMENT ON COLUMN users_message.name IS 'Имя отправителя';
COMMENT ON COLUMN users_message.created IS 'Дата создания сообщения';
COMMENT ON COLUMN users_message.is_read IS 'Флаг, указывающий, прочитано ли сообщение';

-- Комментарии для таблицы users_interest
COMMENT ON TABLE users_interest IS 'Таблица для хранения интересов пользователей';
COMMENT ON COLUMN users_interest.id IS 'Уникальный идентификатор интереса';
COMMENT ON COLUMN users_interest.profile_id IS 'Ссылка на профиль пользователя';
COMMENT ON COLUMN users_interest.name IS 'Название интереса';
COMMENT ON COLUMN users_interest.description IS 'Описание интереса';
COMMENT ON COLUMN users_interest.slug IS 'Уникальный идентификатор интереса в URL';
COMMENT ON COLUMN users_interest.created IS 'Дата создания интереса';

-- Комментарии для таблицы users_profile
COMMENT ON TABLE users_profile IS 'Таблица для хранения профилей пользователей';
COMMENT ON COLUMN users_profile.id IS 'Уникальный идентификатор профиля';
COMMENT ON COLUMN users_profile.user_id IS 'Ссылка на пользователя';
COMMENT ON COLUMN users_profile.name IS 'Имя пользователя';
COMMENT ON COLUMN users_profile.email IS 'Электронная почта пользователя';
COMMENT ON COLUMN users_profile.username IS 'Имя пользователя (логин)';
COMMENT ON COLUMN users_profile.about IS 'Информация о пользователе';
COMMENT ON COLUMN users_profile.summary IS 'Краткое описание профиля';
COMMENT ON COLUMN users_profile.location IS 'Местоположение пользователя';
COMMENT ON COLUMN users_profile.website IS 'Веб-сайт пользователя';
COMMENT ON COLUMN users_profile.image IS 'Ссылка на изображение профиля';
COMMENT ON COLUMN users_profile.created IS 'Дата создания профиля';

-- Комментарии для таблицы blog_category
COMMENT ON TABLE blog_category IS 'Таблица для хранения категорий блога';
COMMENT ON COLUMN blog_category.id IS 'Уникальный идентификатор категории';
COMMENT ON COLUMN blog_category.name IS 'Название категории';
COMMENT ON COLUMN blog_category.slug IS 'Уникальный идентификатор категории в URL';

-- Комментарии для таблицы blog_post
COMMENT ON TABLE blog_post IS 'Таблица для хранения постов блога';
COMMENT ON COLUMN blog_post.id IS 'Уникальный идентификатор поста';
COMMENT ON COLUMN blog_post.title IS 'Заголовок поста';
COMMENT ON COLUMN blog_post.text IS 'Текст поста';
COMMENT ON COLUMN blog_post.published IS 'Дата публикации поста';
COMMENT ON COLUMN blog_post.slug IS 'Уникальный идентификатор поста в URL';
COMMENT ON COLUMN blog_post.owner_id IS 'Ссылка на автора поста';
COMMENT ON COLUMN blog_post.category_id IS 'Ссылка на категорию поста';

-- Комментарии для таблицы blog_post_bookmarks
COMMENT ON TABLE blog_post_bookmarks IS 'Таблица для хранения закладок пользователей на посты';
COMMENT ON COLUMN blog_post_bookmarks.id IS 'Уникальный идентификатор закладки';
COMMENT ON COLUMN blog_post_bookmarks.post_id IS 'Ссылка на пост';
COMMENT ON COLUMN blog_post_bookmarks.user_id IS 'Ссылка на пользователя';

-- Комментарии для таблицы blog_post_likes
COMMENT ON TABLE blog_post_likes IS 'Таблица для хранения лайков пользователей на посты';
COMMENT ON COLUMN blog_post_likes.id IS 'Уникальный идентификатор лайка';
COMMENT ON COLUMN blog_post_likes.post_id IS 'Ссылка на пост';
COMMENT ON COLUMN blog_post_likes.user_id IS 'Ссылка на пользователя';

-- Комментарии для таблицы blog_post_tags
COMMENT ON TABLE blog_post_tags IS 'Таблица для связи постов и тегов';
COMMENT ON COLUMN blog_post_tags.id IS 'Уникальный идентификатор связи поста и тега';
COMMENT ON COLUMN blog_post_tags.post_id IS 'Ссылка на пост';
COMMENT ON COLUMN blog_post_tags.tag_id IS 'Ссылка на тег';

-- Комментарии для таблицы blog_tag
COMMENT ON TABLE blog_tag IS 'Таблица для хранения тегов блога';
COMMENT ON COLUMN blog_tag.id IS 'Уникальный идентификатор тега';
COMMENT ON COLUMN blog_tag.name IS 'Название тега';
COMMENT ON COLUMN blog_tag.slug IS 'Уникальный идентификатор тега в URL';

-- Комментарии для таблицы blog_comment
COMMENT ON TABLE blog_comment IS 'Таблица для хранения комментариев к постам';
COMMENT ON COLUMN blog_comment.id IS 'Уникальный идентификатор комментария';
COMMENT ON COLUMN blog_comment.text IS 'Текст комментария';
COMMENT ON COLUMN blog_comment.published IS 'Дата публикации комментария';
COMMENT ON COLUMN blog_comment.approved IS 'Флаг, указывающий, одобрен ли комментарий';
COMMENT ON COLUMN blog_comment.owner_id IS 'Ссылка на автора комментария';
COMMENT ON COLUMN blog_comment.post_id IS 'Ссылка на пост';

-- Комментарии для таблицы menu_category
COMMENT ON TABLE menu_category IS 'Таблица для хранения категорий меню';
COMMENT ON COLUMN menu_category.id IS 'Уникальный идентификатор категории';
COMMENT ON COLUMN menu_category.name IS 'Название категории';

-- Комментарии для таблицы menu_menu
COMMENT ON TABLE menu_menu IS 'Таблица для хранения блюд меню';
COMMENT ON COLUMN menu_menu.id IS 'Уникальный идентификатор блюда';
COMMENT ON COLUMN menu_menu.dish_name IS 'Название блюда';
COMMENT ON COLUMN menu_menu.description IS 'Описание блюда';
COMMENT ON COLUMN menu_menu.price IS 'Цена блюда';
COMMENT ON COLUMN menu_menu.available IS 'Флаг, указывающий, доступно ли блюдо';
COMMENT ON COLUMN menu_menu.callories IS 'Количество калорий в блюде';
COMMENT ON COLUMN menu_menu.carbohydrates IS 'Количество углеводов в блюде';
COMMENT ON COLUMN menu_menu.fat IS 'Количество жиров в блюде';
COMMENT ON COLUMN menu_menu.protein IS 'Количество белков в блюде';
COMMENT ON COLUMN menu_menu.is_business_lunch IS 'Флаг, указывающий, является ли блюдо частью бизнес-ланча';
COMMENT ON COLUMN menu_menu.place_id IS 'Ссылка на место (ресторан, кафе и т.д.)';
COMMENT ON COLUMN menu_menu.category_id IS 'Ссылка на категорию меню';
COMMENT ON COLUMN menu_menu.created_at IS 'Дата создания записи';
COMMENT ON COLUMN menu_menu.source IS 'Источник блюда (например, рецепт)';

-- Комментарии для таблицы menu_menu_tags
COMMENT ON TABLE menu_menu_tags IS 'Таблица для связи блюд и тегов';
COMMENT ON COLUMN menu_menu_tags.id IS 'Уникальный идентификатор связи блюда и тега';
COMMENT ON COLUMN menu_menu_tags.menu_id IS 'Ссылка на блюдо';
COMMENT ON COLUMN menu_menu_tags.tags_id IS 'Ссылка на тег';

-- Комментарии для таблицы menu_tags
COMMENT ON TABLE menu_tags IS 'Таблица для хранения тегов меню';
COMMENT ON COLUMN menu_tags.id IS 'Уникальный идентификатор тега';
COMMENT ON COLUMN menu_tags.name IS 'Название тега';
COMMENT ON COLUMN menu_tags.slug IS 'Уникальный идентификатор тега в URL';

-- Комментарии для таблицы menu_menu_likes
COMMENT ON TABLE menu_menu_likes IS 'Таблица для хранения лайков пользователей на блюда';
COMMENT ON COLUMN menu_menu_likes.id IS 'Уникальный идентификатор лайка';
COMMENT ON COLUMN menu_menu_likes.menu_id IS 'Ссылка на блюдо';
COMMENT ON COLUMN menu_menu_likes.user_id IS 'Ссылка на пользователя';

-- Комментарии для таблицы delivery_delivery
COMMENT ON TABLE delivery_delivery IS 'Таблица для хранения информации о доставках';
COMMENT ON COLUMN delivery_delivery.id IS 'Уникальный идентификатор доставки';
COMMENT ON COLUMN delivery_delivery.created_by_id IS 'Ссылка на пользователя, создавшего доставку';
COMMENT ON COLUMN delivery_delivery.destination IS 'Место назначения доставки';
COMMENT ON COLUMN delivery_delivery.pick IS 'Место забора доставки';
COMMENT ON COLUMN delivery_delivery.send_at IS 'Дата отправки доставки';
COMMENT ON COLUMN delivery_delivery.created_at IS 'Дата создания доставки';

-- Комментарии для таблицы delivery_meal
COMMENT ON TABLE delivery_meal IS 'Таблица для связи доставок и блюд';
COMMENT ON COLUMN delivery_meal.id IS 'Уникальный идентификатор связи доставки и блюда';
COMMENT ON COLUMN delivery_meal.delivery_id IS 'Ссылка на доставку';
COMMENT ON COLUMN delivery_meal.dish_id IS 'Ссылка на блюдо';

-- Комментарии для таблицы polls_question
COMMENT ON TABLE polls_question IS 'Таблица для хранения вопросов опросов';
COMMENT ON COLUMN polls_question.id IS 'Уникальный идентификатор вопроса';
COMMENT ON COLUMN polls_question.name IS 'Текст вопроса';
COMMENT ON COLUMN polls_question.published IS 'Дата публикации вопроса';

-- Комментарии для таблицы polls_choice
COMMENT ON TABLE polls_choice IS 'Таблица для хранения вариантов ответов на вопросы';
COMMENT ON COLUMN polls_choice.id IS 'Уникальный идентификатор варианта ответа';
COMMENT ON COLUMN polls_choice.name IS 'Текст варианта ответа';
COMMENT ON COLUMN polls_choice.question_id IS 'Ссылка на вопрос';
COMMENT ON COLUMN polls_choice.votes IS 'Количество голосов за вариант ответа';

-- Комментарии для таблицы polls_vote
COMMENT ON TABLE polls_vote IS 'Таблица для хранения голосов пользователей в опросах';
COMMENT ON COLUMN polls_vote.id IS 'Уникальный идентификатор голоса';
COMMENT ON COLUMN polls_vote.choice_id IS 'Ссылка на вариант ответа';
COMMENT ON COLUMN polls_vote.question_id IS 'Ссылка на вопрос';
COMMENT ON COLUMN polls_vote.user_id IS 'Ссылка на пользователя';