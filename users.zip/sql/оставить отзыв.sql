CREATE FUNCTION leave_review(user_id INT, restaurant_id INT, rating INT, comment TEXT)
RETURNS VOID AS $$
BEGIN
    INSERT INTO reviews (user_id, restaurant_id, rating, comment) VALUES (user_id, restaurant_id, rating, comment);
END;
$$ LANGUAGE plpgsql;