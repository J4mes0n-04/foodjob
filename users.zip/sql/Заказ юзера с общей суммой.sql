CREATE VIEW user_orders AS        -- Заказ юзера
SELECT 
    users.user_id,                -- Уникальный идентификатор клиента
    users.username,               -- Имя клиента
    orders.order_id,              -- Уникальный идентификатор заказа
    orders.order_date,            -- Дата и время оформления заказа
    SUM(menu_items.price * order_items.quantity) AS total_amount  -- Общая сумма заказа
FROM 
    users
JOIN 
    orders ON users.user_id = orders.user_id
JOIN 
    order_items ON orders.order_id = order_items.order_id
JOIN 
    menu_items ON order_items.menu_item_id = menu_items.item_id
GROUP BY 
    users.user_id, orders.order_id; 
