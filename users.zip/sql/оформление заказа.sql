CREATE FUNCTION create_order(user_id INT, restaurant_id INT, items JSONB)
RETURNS INT AS $$
DECLARE
    order_id INT;
BEGIN
    INSERT INTO orders (user_id, restaurant_id, order_date) VALUES (user_id, restaurant_id, NOW()) RETURNING order_id INTO order_id;
    -- Добавить элементы в заказ
    INSERT INTO order_items (order_id, menu_item_id, quantity) 
    SELECT order_id, (item->>'menu_item_id')::INT, (item->>'quantity')::INT FROM jsonb_array_elements(items) AS item;
    RETURN order_id;
END;
$$ LANGUAGE plpgsql;