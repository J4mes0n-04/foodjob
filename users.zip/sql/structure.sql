-- auth_group definition

CREATE TABLE "auth_group" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "name" varchar(150) NOT NULL UNIQUE);


-- auth_user definition

CREATE TABLE "auth_user" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "password" varchar(128) NOT NULL, "last_login" datetime NULL, "is_superuser" bool NOT NULL, "username" varchar(150) NOT NULL UNIQUE, "last_name" varchar(150) NOT NULL, "email" varchar(254) NOT NULL, "is_staff" bool NOT NULL, "is_active" bool NOT NULL, "date_joined" datetime NOT NULL, "first_name" varchar(150) NOT NULL);


-- blog_category definition

CREATE TABLE "blog_category" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "name" varchar(20) NOT NULL, "slug" varchar(50) NOT NULL);

CREATE INDEX "blog_category_slug_92643dc5" ON "blog_category" ("slug");


-- blog_tag definition

CREATE TABLE "blog_tag" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "name" varchar(20) NOT NULL, "slug" varchar(50) NOT NULL);

CREATE INDEX "blog_tag_slug_01068d0e" ON "blog_tag" ("slug");


-- django_content_type definition

CREATE TABLE "django_content_type" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "app_label" varchar(100) NOT NULL, "model" varchar(100) NOT NULL);

CREATE UNIQUE INDEX "django_content_type_app_label_model_76bd3d3b_uniq" ON "django_content_type" ("app_label", "model");


-- django_mailbox_mailbox definition

CREATE TABLE "django_mailbox_mailbox" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "name" varchar(255) NOT NULL, "uri" varchar(255) NULL, "from_email" varchar(255) NULL, "active" bool NOT NULL, "last_polling" datetime NULL);


-- django_migrations definition

CREATE TABLE "django_migrations" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "app" varchar(255) NOT NULL, "name" varchar(255) NOT NULL, "applied" datetime NOT NULL);


-- django_session definition

CREATE TABLE "django_session" ("session_key" varchar(40) NOT NULL PRIMARY KEY, "session_data" text NOT NULL, "expire_date" datetime NOT NULL);

CREATE INDEX "django_session_expire_date_a5c62663" ON "django_session" ("expire_date");


-- menu_category definition

CREATE TABLE "menu_category" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "name" varchar(255) NOT NULL);


-- polls_question definition

CREATE TABLE "polls_question" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "name" varchar(300) NOT NULL, "published" datetime NOT NULL);


-- auth_permission definition

CREATE TABLE "auth_permission" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "content_type_id" integer NOT NULL REFERENCES "django_content_type" ("id") DEFERRABLE INITIALLY DEFERRED, "codename" varchar(100) NOT NULL, "name" varchar(255) NOT NULL);

CREATE UNIQUE INDEX "auth_permission_content_type_id_codename_01ab375a_uniq" ON "auth_permission" ("content_type_id", "codename");
CREATE INDEX "auth_permission_content_type_id_2f476e4b" ON "auth_permission" ("content_type_id");


-- auth_user_groups definition

CREATE TABLE "auth_user_groups" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "user_id" integer NOT NULL REFERENCES "auth_user" ("id") DEFERRABLE INITIALLY DEFERRED, "group_id" integer NOT NULL REFERENCES "auth_group" ("id") DEFERRABLE INITIALLY DEFERRED);

CREATE UNIQUE INDEX "auth_user_groups_user_id_group_id_94350c0c_uniq" ON "auth_user_groups" ("user_id", "group_id");
CREATE INDEX "auth_user_groups_user_id_6a12ed8b" ON "auth_user_groups" ("user_id");
CREATE INDEX "auth_user_groups_group_id_97559544" ON "auth_user_groups" ("group_id");


-- auth_user_user_permissions definition

CREATE TABLE "auth_user_user_permissions" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "user_id" integer NOT NULL REFERENCES "auth_user" ("id") DEFERRABLE INITIALLY DEFERRED, "permission_id" integer NOT NULL REFERENCES "auth_permission" ("id") DEFERRABLE INITIALLY DEFERRED);

CREATE UNIQUE INDEX "auth_user_user_permissions_user_id_permission_id_14a6b632_uniq" ON "auth_user_user_permissions" ("user_id", "permission_id");
CREATE INDEX "auth_user_user_permissions_user_id_a95ead1b" ON "auth_user_user_permissions" ("user_id");
CREATE INDEX "auth_user_user_permissions_permission_id_1fbb5f2c" ON "auth_user_user_permissions" ("permission_id");


-- django_admin_log definition

CREATE TABLE "django_admin_log" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "object_id" text NULL, "object_repr" varchar(200) NOT NULL, "action_flag" smallint unsigned NOT NULL CHECK ("action_flag" >= 0), "change_message" text NOT NULL, "content_type_id" integer NULL REFERENCES "django_content_type" ("id") DEFERRABLE INITIALLY DEFERRED, "user_id" integer NOT NULL REFERENCES "auth_user" ("id") DEFERRABLE INITIALLY DEFERRED, "action_time" datetime NOT NULL);

CREATE INDEX "django_admin_log_content_type_id_c4bce8eb" ON "django_admin_log" ("content_type_id");
CREATE INDEX "django_admin_log_user_id_c564eba6" ON "django_admin_log" ("user_id");


-- django_mailbox_message definition

CREATE TABLE "django_mailbox_message" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "subject" varchar(255) NOT NULL, "message_id" varchar(255) NOT NULL, "from_header" varchar(255) NOT NULL, "to_header" text NOT NULL, "outgoing" bool NOT NULL, "body" text NOT NULL, "encoded" bool NOT NULL, "processed" datetime NOT NULL, "read" datetime NULL, "mailbox_id" integer NOT NULL REFERENCES "django_mailbox_mailbox" ("id") DEFERRABLE INITIALLY DEFERRED, "eml" varchar(100) NULL, "in_reply_to_id" integer NULL REFERENCES "django_mailbox_message" ("id") DEFERRABLE INITIALLY DEFERRED);

CREATE INDEX "django_mailbox_message_mailbox_id_d60c2b04" ON "django_mailbox_message" ("mailbox_id");
CREATE INDEX "django_mailbox_message_in_reply_to_id_296753b5" ON "django_mailbox_message" ("in_reply_to_id");


-- django_mailbox_messageattachment definition

CREATE TABLE "django_mailbox_messageattachment" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "headers" text NULL, "message_id" integer NULL REFERENCES "django_mailbox_message" ("id") DEFERRABLE INITIALLY DEFERRED, "document" varchar(100) NOT NULL);

CREATE INDEX "django_mailbox_messageattachment_message_id_3f4d2dee" ON "django_mailbox_messageattachment" ("message_id");


-- polls_choice definition

CREATE TABLE "polls_choice" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "name" varchar(200) NOT NULL, "votes" integer NOT NULL, "question_id" bigint NOT NULL REFERENCES "polls_question" ("id") DEFERRABLE INITIALLY DEFERRED);

CREATE INDEX "polls_choice_question_id_c5b4b260" ON "polls_choice" ("question_id");


-- polls_vote definition

CREATE TABLE "polls_vote" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "choice_id" bigint NOT NULL REFERENCES "polls_choice" ("id") DEFERRABLE INITIALLY DEFERRED, "question_id" bigint NOT NULL REFERENCES "polls_question" ("id") DEFERRABLE INITIALLY DEFERRED, "user_id" integer NOT NULL REFERENCES "auth_user" ("id") DEFERRABLE INITIALLY DEFERRED);

CREATE INDEX "polls_vote_choice_id_17e8b17c" ON "polls_vote" ("choice_id");
CREATE INDEX "polls_vote_question_id_5ba63147" ON "polls_vote" ("question_id");
CREATE INDEX "polls_vote_user_id_49d78cb7" ON "polls_vote" ("user_id");


-- users_profile definition

CREATE TABLE "users_profile" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "name" varchar(50) NULL, "email" varchar(50) NULL, "username" varchar(50) NULL, "summary" varchar(100) NULL, "about" text NULL, "image" varchar(100) NULL, "website" varchar(100) NOT NULL, "created" datetime NOT NULL, "location" varchar(255) NULL, "user_id" integer NULL UNIQUE REFERENCES "auth_user" ("id") DEFERRABLE INITIALLY DEFERRED);


-- auth_group_permissions definition

CREATE TABLE "auth_group_permissions" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "group_id" integer NOT NULL REFERENCES "auth_group" ("id") DEFERRABLE INITIALLY DEFERRED, "permission_id" integer NOT NULL REFERENCES "auth_permission" ("id") DEFERRABLE INITIALLY DEFERRED);

CREATE UNIQUE INDEX "auth_group_permissions_group_id_permission_id_0cd325b0_uniq" ON "auth_group_permissions" ("group_id", "permission_id");
CREATE INDEX "auth_group_permissions_group_id_b120cbf9" ON "auth_group_permissions" ("group_id");
CREATE INDEX "auth_group_permissions_permission_id_84c5c92e" ON "auth_group_permissions" ("permission_id");


-- blog_post definition

CREATE TABLE "blog_post" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "title" varchar(150) NOT NULL, "slug" varchar(50) NOT NULL, "text" text NOT NULL, "published" datetime NOT NULL, "category_id" bigint NOT NULL REFERENCES "blog_category" ("id") DEFERRABLE INITIALLY DEFERRED, "owner_id" bigint NULL REFERENCES "users_profile" ("id") DEFERRABLE INITIALLY DEFERRED);

CREATE INDEX "blog_post_slug_b95473f2" ON "blog_post" ("slug");
CREATE INDEX "blog_post_category_id_c326dbf8" ON "blog_post" ("category_id");
CREATE INDEX "blog_post_owner_id_ff7c9277" ON "blog_post" ("owner_id");


-- blog_post_bookmarks definition

CREATE TABLE "blog_post_bookmarks" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "post_id" bigint NOT NULL REFERENCES "blog_post" ("id") DEFERRABLE INITIALLY DEFERRED, "user_id" integer NOT NULL REFERENCES "auth_user" ("id") DEFERRABLE INITIALLY DEFERRED);

CREATE UNIQUE INDEX "blog_post_bookmarks_post_id_user_id_424b7590_uniq" ON "blog_post_bookmarks" ("post_id", "user_id");
CREATE INDEX "blog_post_bookmarks_post_id_eb9c59a3" ON "blog_post_bookmarks" ("post_id");
CREATE INDEX "blog_post_bookmarks_user_id_754ad243" ON "blog_post_bookmarks" ("user_id");


-- blog_post_likes definition

CREATE TABLE "blog_post_likes" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "post_id" bigint NOT NULL REFERENCES "blog_post" ("id") DEFERRABLE INITIALLY DEFERRED, "user_id" integer NOT NULL REFERENCES "auth_user" ("id") DEFERRABLE INITIALLY DEFERRED);

CREATE UNIQUE INDEX "blog_post_likes_post_id_user_id_54f740f5_uniq" ON "blog_post_likes" ("post_id", "user_id");
CREATE INDEX "blog_post_likes_post_id_d038881a" ON "blog_post_likes" ("post_id");
CREATE INDEX "blog_post_likes_user_id_bfe15394" ON "blog_post_likes" ("user_id");


-- blog_post_tags definition

CREATE TABLE "blog_post_tags" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "post_id" bigint NOT NULL REFERENCES "blog_post" ("id") DEFERRABLE INITIALLY DEFERRED, "tag_id" bigint NOT NULL REFERENCES "blog_tag" ("id") DEFERRABLE INITIALLY DEFERRED);

CREATE UNIQUE INDEX "blog_post_tags_post_id_tag_id_4925ec37_uniq" ON "blog_post_tags" ("post_id", "tag_id");
CREATE INDEX "blog_post_tags_post_id_a1c71c8a" ON "blog_post_tags" ("post_id");
CREATE INDEX "blog_post_tags_tag_id_0875c551" ON "blog_post_tags" ("tag_id");


-- menu_menu definition

CREATE TABLE "menu_menu" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "dish_name" varchar(255) NOT NULL, "price" decimal NOT NULL, "description" text NULL, "available" bool NOT NULL, "category_id" bigint NULL REFERENCES "menu_category" ("id") DEFERRABLE INITIALLY DEFERRED, "place_id" bigint NULL REFERENCES "users_profile" ("id") DEFERRABLE INITIALLY DEFERRED, "created_at" datetime NOT NULL);

CREATE INDEX "menu_menu_category_id_f720cec5" ON "menu_menu" ("category_id");
CREATE INDEX "menu_menu_place_id_6532ddeb" ON "menu_menu" ("place_id");


-- users_interest definition

CREATE TABLE "users_interest" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "name" varchar(50) NULL, "slug" varchar(50) NOT NULL, "description" text NULL, "created" datetime NOT NULL, "profile_id" bigint NULL REFERENCES "users_profile" ("id") DEFERRABLE INITIALLY DEFERRED);

CREATE UNIQUE INDEX "users_interest_name_slug_profile_id_c8d0ca43_uniq" ON "users_interest" ("name", "slug", "profile_id");
CREATE INDEX "users_interest_slug_653b564f" ON "users_interest" ("slug");
CREATE INDEX "users_interest_profile_id_2f81d2e8" ON "users_interest" ("profile_id");


-- users_message definition

CREATE TABLE "users_message" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "name" varchar(200) NULL, "email" varchar(200) NULL, "subject" varchar(200) NULL, "body" text NOT NULL, "is_read" bool NULL, "created" datetime NOT NULL, "recipient_id" bigint NULL REFERENCES "users_profile" ("id") DEFERRABLE INITIALLY DEFERRED, "sender_id" bigint NULL REFERENCES "users_profile" ("id") DEFERRABLE INITIALLY DEFERRED);

CREATE INDEX "users_message_recipient_id_0dcb937f" ON "users_message" ("recipient_id");
CREATE INDEX "users_message_sender_id_d1e3d44e" ON "users_message" ("sender_id");


-- blog_comment definition

CREATE TABLE "blog_comment" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "text" text NOT NULL, "published" datetime NOT NULL, "approved" bool NOT NULL, "owner_id" bigint NULL REFERENCES "users_profile" ("id") DEFERRABLE INITIALLY DEFERRED, "post_id" bigint NOT NULL REFERENCES "blog_post" ("id") DEFERRABLE INITIALLY DEFERRED);

CREATE INDEX "blog_comment_owner_id_d904784e" ON "blog_comment" ("owner_id");
CREATE INDEX "blog_comment_post_id_580e96ef" ON "blog_comment" ("post_id");