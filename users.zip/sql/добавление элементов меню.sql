CREATE FUNCTION add_menu_item(restaurant_id INT, item_name VARCHAR, price DECIMAL)
RETURNS VOID AS $$
BEGIN
    INSERT INTO menu_items (restaurant_id, name, price) VALUES (restaurant_id, item_name, price);
END;
$$ LANGUAGE plpgsql;