CREATE VIEW active_menu AS
SELECT 
    menu_items.menu_id,
    menu_items.item_id,
    menu_items.name AS item_name,
    menu_items.description,
    menu_items.price,    
    menus.date_start,
    menus.date_end,
    food_place.name AS restaurant_name
FROM 
    menu_items
JOIN 
    menus ON menu_items.menu_id = menus.menu_id
 JOIN 
    food_place ON menus.restaurant_id = food_place.id
WHERE 
    menu_items.is_available = TRUE AND menus.is_active = TRUE;