
CREATE TABLE users (
    user_id INT PRIMARY KEY, --УИ
    username VARCHAR(255),   --Имя подльзователя
    password VARCHAR(255),   --Пароль
    email VARCHAR(255),      --Почта
    role varchar,            --Роль (юзер, админ, партнер)
    created_at DATETIME,     --Дата регистрации
    phone_number VARCHAR(50) --Номер телефона пользователя 
);
CREATE TABLE food_place (
    restaurant_id INT PRIMARY KEY,      -- УИ
    name VARCHAR(255),                   -- Название ресторана
    address VARCHAR(255),                -- Адрес ресторана (Улица, Дом)
    phone VARCHAR(50),                   -- Телефон ресторана
    description TEXT,                    -- Описание ресторана
    type VARCHAR(50),                    -- Категория ресторана (Доставка, столовая, кафе, ресторан, бар)
    owner_id INT,                        -- Идентификатор владельца ресторана
    FOREIGN KEY (owner_id) REFERENCES Users(user_id)  -- Внешний ключ на таблицу Users
);

CREATE TABLE menus (
    menu_id INT NOT NULL PRIMARY KEY AUTOINCREMENT,             -- УИ
    restaurant_id INT NOT NULL,                   -- Идентификатор ресторана, к которому относится меню
    date_start DATE NOT NULL,                     -- Дата, на которую актуально меню
    date_end DATE NOT NULL,                       -- Дата, дата закрытия меню
    is_active BOOLEAN,                   -- Статус активности меню (активно/неактивно)
    FOREIGN KEY (restaurant_id) REFERENCES Restaurants(restaurant_id)  -- Внешний ключ на таблицу Restaurants
);

CREATE TABLE menu_items (
    item_id INT NOT NULL PRIMARY KEY AUTOINCREMENT,             -- УИ
    menu_id INT NOT NULL,                         -- Идентификатор меню, к которому относится элемент
    name VARCHAR(255) NOT NULL,                   -- Название элемента меню
    description TEXT NOT NULL,                    -- Описание элемента меню
    price DECIMAL(10, 2) NOT NULL,                -- Цена элемента меню (с двумя знаками после запятой)
    is_available BOOLEAN,                -- Статус доступности элемента меню (доступен/недоступен)
    FOREIGN KEY (menu_id) REFERENCES Menus(menu_id)  -- Внешний ключ на таблицу Menus
);

CREATE TABLE orders (
    order_id INT NOT NULL PRIMARY KEY AUTOINCREMENT,            -- УИ
    user_id INT NOT NULL,                         -- Идентификатор пользователя, сделавшего заказ
    restaurant_id INT NOT NULL,                   -- Идентификатор ресторана, где был сделан заказ
    order_date DATETIME NOT NULL,                 -- Дата и время оформления заказа
    status VARCHAR(50) NOT NULL,                  -- Статус заказа (например, "в ожидании", "доставлен" и т.д.)
    FOREIGN KEY (user_id) REFERENCES Users(user_id),  -- Внешний ключ на таблицу Users
    FOREIGN KEY (restaurant_id) REFERENCES Restaurants(restaurant_id)  -- Внешний ключ на таблицу Restaurants
);

CREATE TABLE Reviews (
    order_id INT NOT NULL PRIMARY KEY AUTOINCREMENT,           -- Уникальный идентификатор отзыва
    user_id INT NOT NULL,                         -- Идентификатор пользователя, оставившего отзыв
    restaurant_id INT NOT NULL,                   -- Идентификатор ресторана, к которому относится отзыв
    rating INT NOT NULL,                          -- Оценка ресторана (например, от 1 до 5)
    comment TEXT NOT NULL,                        -- Комментарий отзыва
    created_at DATETIME NOT NULL,                 -- Дата и время создания отзыва
    FOREIGN KEY (user_id) REFERENCES Users(user_id),  -- Внешний ключ на таблицу Users
    FOREIGN KEY (restaurant_id) REFERENCES Restaurants(restaurant_id)  -- Внешний ключ на таблицу Restaurants
);

 CREATE TABLE order_items (
    order_item_id INT PRIMARY KEY ,                 -- Уникальный идентификатор позиции заказа
    order_id INT NOT NULL,                          -- Идентификатор заказа
    menu_item_id INT NOT NULL,                      -- Идентификатор позиции меню
    quantity INT NOT NULL,                          -- Количество заказанных единиц
    price DECIMAL(10, 2) NOT NULL,                  -- Цена за единицу
    FOREIGN KEY (order_id) REFERENCES orders(order_id),  -- Внешний ключ на таблицу Orders
    FOREIGN KEY (menu_item_id) REFERENCES menu(item_id)  -- Внешний ключ на таблицу Menu
);