
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('blog.urls')),
    path('', include('users.urls')),
    path('', include('polls.urls')),
    path('', include('menu.urls')), 
    path('', include('django.contrib.auth.urls')),
    path('', include('delivery.urls')), 
    path('', include('mailbot.urls')), 
    path('', include('bonus.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
