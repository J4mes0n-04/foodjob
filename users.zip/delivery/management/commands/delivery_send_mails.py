from django.core.management.base import BaseCommand
from delivery.models import Delivery
from delivery.views import process_pending_deliveries

class Command(BaseCommand):
    help = 'Send pending delivery emails'

    def handle(self, *args, **kwargs):
        process_pending_deliveries()
        self.stdout.write(self.style.SUCCESS('Emails sent successfully'))
