from django.shortcuts import render, redirect, get_object_or_404
from .forms import BusinessLunchOrderForm
from .models import Delivery, Menu, Meal
from django.contrib.auth.decorators import login_required
from users.models import Profile
from mailbot.utils import send_email
from django.template.loader import render_to_string
from django.utils import timezone
from collections import defaultdict
from django.http import HttpResponse

@login_required
def business_lunch_order(request):
    place =  Profile.objects.get(id=1)
    # request.user.profile  # Или другой способ определения заведения
    if request.method == 'POST':
        form = BusinessLunchOrderForm(request.POST, place=place)
        if form.is_valid():
            # Создание заказа
            pick = request.POST.get('pick') == 'True'
            destination = request.POST.get('destination', '') if not pick else ''
            delivery = Delivery.objects.create(
                destination=destination,
                pick=pick,
                created_by=request.user
            )
            # Добавить выбранные блюда
            for field_name, dish_id in form.cleaned_data.items():
                if dish_id:
                    dish = Menu.objects.get(id=dish_id)
                    Meal.objects.create(delivery=delivery, dish=dish)
            return redirect('delivery:order_success', delivery_id=delivery.id)
    else:
        form = BusinessLunchOrderForm(place=place)

    return render(request, 'business_lunch_order.html', {'form': form})

@login_required
def success(request, delivery_id):
    # Получаем объект заказа по ID
    delivery = get_object_or_404(Delivery, id=delivery_id)
    
    # Логика текста в зависимости от pick и destination
    if delivery.pick:
        message = "Вы сможете забрать заказ на точке выдачи на 1 этаже после 12:00."
    else:
        message = f"Заказ вам доставят на {delivery.destination} этаж на общую кухню в 11:45."
    
    return render(request, 'success.html', {
        'delivery_id': delivery.id,
        'message': message,
    })

def process_pending_deliveries():
    process_orders_pick()
    process_orders_delivery()

def process_orders_delivery():

    # Получаем все заказы с send_at=None и pick=False
    pending_deliveries = Delivery.objects.filter(send_at__isnull=True, pick=False)
    
    # Группируем заказы по этажам
    deliveries_by_floor = defaultdict(list)
    for delivery in pending_deliveries:
        if delivery.destination:  # Убедимся, что этаж указан
            deliveries_by_floor[delivery.destination].append(delivery)
    

    # Обрабатываем заказы для каждого этажа
    for floor, deliveries in deliveries_by_floor.items():
        # Собираем блюда и их количество
        dish_count = defaultdict(int)
        for delivery in deliveries:
            meals = Meal.objects.filter(delivery=delivery)
            for meal in meals:
                dish_count[meal.dish.dish_name] += 1

        dish_count=dict(dish_count)

        first_delivery = deliveries[0]  # Получаем любой заказ с этого этажа
        first_meal = Meal.objects.filter(delivery=first_delivery).first()
        place = first_meal.dish.place if first_meal else None
        email = place.email if place else 'default@example.com'  # Замените на нужный fallback email
        # Формируем контекст для шаблона
        context = {
            'floor': floor,
            'date': timezone.now().strftime('%Y-%m-%d'),  # Дата без времени
            'dish_count': dish_count,  # Блюда и их количество
            'deliveries': deliveries,  # Все заказы для этого этажа
        }

        # Генерируем HTML текст из шаблона
        message_html = render_to_string('order_delivery_email.html', context)

        # Отправка письма
        send_email(
            subject=f'Доставка на этаж {floor}',
            body="Доставка на этаж",  # fallback-текст для текстовой версии
            recipients=[email],  # Укажите email получателя (например, для курьера)
            html_message=message_html,
        )

        # Обновляем поле send_at для всех обработанных заказов
        for delivery in deliveries:
            delivery.send_at = timezone.now()
            delivery.save()
    django_response = HttpResponse(status=200)
    return django_response 

def process_orders_pick():

    # Получаем все заказы с send_at=None и pick=True
    pending_deliveries = Delivery.objects.filter(send_at__isnull=True, pick=True)
    
    for delivery in pending_deliveries:
     
        # Получаем список блюд в заказе
        meals = delivery.meal_set.all()
        dish_names = [meal.dish.dish_name for meal in meals]
  
        # Формируем контекст для шаблона
        context = {
            'order_id': delivery.id,
            'order_type': "Самовывоз",
            'user_name': delivery.created_by.get_full_name() or delivery.created_by.username,
            'created_at': delivery.created_at.strftime('%Y-%m-%d %H:%M:%S'),
            'dish_names': dish_names,
        }
        
        first_meal = Meal.objects.filter(delivery=delivery).first()
        place = first_meal.dish.place if first_meal else None
        email = place.email if place else 'default@example.com'  # Замените на нужный fallback email

        # Генерируем HTML текст из шаблона
        message_html = render_to_string('order_pick_email.html', context)
   
        # Отправка письма
        send_email(
            subject=f'Заказ №{delivery.id}',
            body="Заказ на самовывоз",  # fallback-текст для текстовой версии
            recipients=[email,],
            html_message=message_html,
        )
        # Обновляем поле send_at
        delivery.send_at = timezone.now()
        delivery.save()