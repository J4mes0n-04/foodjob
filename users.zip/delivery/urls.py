from django.urls import path
from .views import business_lunch_order, success, process_pending_deliveries

app_name = "delivery"

urlpatterns = [
    path('business-lunch/', business_lunch_order, name='business_lunch'),
    path('success/<int:delivery_id>/', success, name='order_success'),
    path('delivery-send-mails/', lambda request: process_pending_deliveries(), name='delivery_send_mails'),

]