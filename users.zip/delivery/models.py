from django.db import models
from django.contrib.auth.models import User
from menu.models import Menu

# Create your models here.
class Delivery(models.Model):
    # заказ бизнес ланча
    # id это номер
    # Этаж
    destination=models.CharField(max_length=150,blank=True, null=True)
    # 
    created_at = models.DateTimeField(auto_now_add=True)
    created_by = models.ForeignKey(
        User, null=True, blank=True, on_delete=models.CASCADE)
    # флаг, что отправлено и обработано
    send_at=models.DateTimeField(blank=True, null=True)
    # сам заберет или доставка
    pick=models.BooleanField(blank=True, null=True)

class Meal(models.Model):
    # блюдо в доставке
    delivery = models.ForeignKey(Delivery, 
        on_delete=models.CASCADE)
    dish=models.ForeignKey(Menu, 
        on_delete=models.CASCADE)