from django import forms
from menu.models import Menu,Category
from delivery.models import Delivery

class BusinessLunchOrderForm(forms.Form):
    def __init__(self, *args, **kwargs):
        place = kwargs.pop('place', None)
        super().__init__(*args, **kwargs)
        
        # Получить все доступные категории
        categories = Menu.objects.filter(place=place, available=True, is_business_lunch=True).values_list('category', flat=True).distinct()

        for category_id in categories:
            category = Category.objects.get(id=category_id)
            dishes = Menu.objects.filter(
                place=place, available=True, category=category, is_business_lunch=True
            )

            choices = [(dish.id, dish.dish_name) for dish in dishes]

            self.fields[f'category_{category.id}'] = forms.ChoiceField(
                label=category.name,
                choices=choices,
                widget=forms.RadioSelect,
                required=False
            )
